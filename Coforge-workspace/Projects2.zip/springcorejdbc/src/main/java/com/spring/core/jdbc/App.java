package com.spring.core.jdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.spring.core.entities.Student;
import com.spring.jdbc.dao.StudentDao;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context=new ClassPathXmlApplicationContext("com/spring/core/jdbc/config.xml");
        StudentDao studentDao = context.getBean("studentdao",StudentDao.class);
        
         Student student = new Student();
         
         // 1 Inserting data into student
         
//         
//         student.setId(11);
//         student.setName("Abhishek");
//         student.setCity("Bihar");
//         int insert = studentDao.insert(student);
//         System.out.println(insert+" value inserted");
         
        // 2 Updating data in student
         
//         student.setName("Vikash");
//         student.setCity("kanpur");
//         student.setId(598);
//         
//         int update2 = studentDao.update1(student);
//         System.out.println(update2+"  Student have been updated successfully");
         
         student.setId(121);
         int delete2 = studentDao.delete1(student);
         System.out.println(delete2+" Student have been deleted successfully");
        
    }
}
