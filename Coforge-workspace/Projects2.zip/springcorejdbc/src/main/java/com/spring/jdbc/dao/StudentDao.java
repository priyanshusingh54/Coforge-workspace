package com.spring.jdbc.dao;

import com.spring.core.entities.Student;

public interface StudentDao {
	public int insert(Student student);
	public int update1(Student student);
	public int delete1(Student student);
	

}
