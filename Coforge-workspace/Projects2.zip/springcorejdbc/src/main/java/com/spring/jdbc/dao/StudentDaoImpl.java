package com.spring.jdbc.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.spring.core.entities.Student;

public  class StudentDaoImpl implements StudentDao{
	
	private JdbcTemplate jdbcTemplate;

	//@Override
	public int insert(Student student) {
		
		String query="insert into student(id,name,city) values(?,?,?)";
		int update = this.jdbcTemplate.update(query,student.getId(),student.getName(),student.getCity());
	
		System.out.println(update);
		return update;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	//@Override
	public int update1(Student student) {
		String query="update student set name=? , city=? where id=?";
		int up = jdbcTemplate.update(query,student.getName(),student.getCity(),student.getId());
		return up;
	}

	//@Override
	public int delete1(Student student) {
		String query="delete from student where id=?";
		int del = jdbcTemplate.update(query, student.getId());
		return del;
	}
	
	
}
