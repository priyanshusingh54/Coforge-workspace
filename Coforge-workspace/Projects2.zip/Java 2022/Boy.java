import java.util.Scanner;

public class Boy{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int age = sc.nextInt();
		//sc.close();
		System.out.println(age);
		/*if (age>18)
		{
			System.out.println("Yor Can Go");
		}
		else {
			System.out.println("You can't Go");
		}*/
	}}


