import java.util.Scanner;

public class String3 {
    public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
System.out.println();
String st = sc.nextLine();
sc.close();
System.out.println(st);
    }
}


