import java.util.Scanner;

public class Test{
    public static void main(String args[])
    {
    	String x="Akash";
    	String y;
    	Scanner sc = new Scanner(System.in);
        System.out.println("Enter your Last name : ");
        y=sc.nextLine();
        sc.close();
        System.out.println(x+" "+y);
    
	}
} 