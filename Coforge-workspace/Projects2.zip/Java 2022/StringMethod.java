
public class StringMethod {

	public static void main(String[] args) {
		String name = "Akash";
		String st  = "Singh";
		System.out.println(name.toUpperCase()+ " "+st);  // Akash Singh
		System.out.println(st.toUpperCase());   // Singh
		System.out.println(name.toLowerCase());  // akash
		System.out.println(st.endsWith("gh"));// True 
		System.out.println(name.contains("ka"));
		System.out.println(name.charAt(3));   // s
		System.out.println(name.indexOf("ka"));    // 1
		System.out.println(name + st);
		
		//  See on google java String Method
	}

}
