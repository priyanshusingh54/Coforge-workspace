
public class MathClass {

	public static void main(String[] args) {
		int a =2, b=5;
		System.out.println(Math.max(a, b));   //=> 5
		System.out.println(Math.min(a, b));  // 2
		System.out.println(Math.sqrt(b));
		System.out.println(Math.abs(a));
	}

}  
