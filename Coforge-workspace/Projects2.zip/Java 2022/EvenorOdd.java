import java.util.Scanner;

public class EvenorOdd 
{
	public static void main(String[] args)
	{
		
		Scanner scanner = new Scanner(System.in);
		int num =scanner.nextInt();
		scanner.close();
		if(num/2==0) {
			System.out.println("even no");
		}
		else {
			System.out.println("Odd no");
		}
		
	
	     
	}

}
