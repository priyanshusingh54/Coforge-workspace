import java.util.Scanner;

public class IfCondition {
	public static void main(String[] args) {
		Scanner sc1 = new Scanner(System.in);
		int age = sc1.nextInt();
		sc1.close();
		if (age>=18)
		{
			System.out.println("Yor Can Go");
		}
		else {
			System.out.println("You can't Go");
		}
	}

}
