package com.spring.core.reference2;

public class Math2 {
	private int y;

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public Math2(int y) {
		super();
		this.y = y;
	}

	public Math2() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Math2 [y=" + y + "]";
	}
	
	

}
