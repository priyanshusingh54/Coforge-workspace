package com.spring.core.reference2;

public class Math1 {
	private int x;
	private Math2 ob;
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public Math2 getOb() {
		return ob;
	}
	public void setOb(Math2 ob) {
		this.ob = ob;
	}
	public Math1(int x, Math2 ob) {
		super();
		this.x = x;
		this.ob = ob;
	}
	public Math1() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Math1 [x=" + x + ", ob=" + ob + "]";
	}
	
	

}
