package com.spring.core.collection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmplopyee {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/spring/core/collection/collectionconfig.xml");
		Employee employee =(Employee) context.getBean("Employee1");
		System.out.println(employee.getName());
		System.out.println(employee.getCourses());
		System.out.println(employee.getAddresses());
		System.out.println(employee.getPhones());
	
		
	}

}
