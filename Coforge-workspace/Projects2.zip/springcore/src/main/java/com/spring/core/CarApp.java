package com.spring.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CarApp {

	public static void main(String[] args) {
		System.out.println("This is my 2nd Program");
		
		ApplicationContext context= new ClassPathXmlApplicationContext("cardata.xml");
		
		Car car1= (Car) context.getBean("car1");
		
		System.out.println(car1);

	} 

}
