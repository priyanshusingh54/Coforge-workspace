package com.spring.core.constractor.injection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestPerson {

	public static void main(String[] args) {

// 1--> creating object for Person ApplicationContext
		
		ApplicationContext context=new ClassPathXmlApplicationContext
				("com/spring/core/constractor/injection/ciconfig.xml");
		Person person=(Person) context.getBean("Data1");
		System.out.println(person);

		
// 2--> creating object for Subject using AbstractApplicationContext
		
		AbstractApplicationContext context1=new ClassPathXmlApplicationContext
		("com/spring/core/constractor/injection/ciconfig.xml");
		Subject subject=(Subject) context1.getBean("Sub");
		System.out.println(subject);
		subject.end();
		subject.start();
	}
	

}
