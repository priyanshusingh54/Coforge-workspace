package com.spring.core.constractor.injection;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Subject {
	private String lession;

	public String getLession() {
		return lession;
	}

	public void setLession(String lession) {
		System.out.println("Setting lession");
		this.lession = lession;
	}

	public Subject() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Subject [lession=" + lession + "]";
	}
	
	@PostConstruct
	public void start()
	{
		System.out.println("Staring Lession");
	}
	
	@PreDestroy
	public void end()
	{
		System.out.println("Ending");
	}

}
