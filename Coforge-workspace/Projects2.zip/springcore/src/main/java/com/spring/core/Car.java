package com.spring.core;

public class Car {
	
	private int price;
	private int model;
	private String name;
	private String color;
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
		
	}
	public int getModel() {
		return model;
	}
	public void setModel(int model) {
		this.model = model;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Car(int price, int model, String name, String color) {
		super();
		this.price = price;
		this.model = model;
		this.name = name;
		this.color = color;
	}
	@Override
	public String toString() {
		return "Car [price=" + price + ", model=" + model + ", name=" + name + ", color=" + color + "]";
	}
	
	

}
