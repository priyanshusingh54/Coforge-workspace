package com.spring.core.autowire;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context4 = new ClassPathXmlApplicationContext("com/spring/core/autowire/config.xml");
		Student student3 = context4.getBean("student",Student.class);
		System.out.println(student3);
	}

}
