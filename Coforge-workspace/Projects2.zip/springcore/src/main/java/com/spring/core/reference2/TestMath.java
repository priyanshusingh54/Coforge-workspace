package com.spring.core.reference2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMath {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("/com/spring/core/reference2/ref2config.xml");

		Math1 temp=(Math1) context.getBean("Mathmatics1");
		System.out.println(temp.getOb().getY());
		System.out.println(temp.getX());
	}

}
