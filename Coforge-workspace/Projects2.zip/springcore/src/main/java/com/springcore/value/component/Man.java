package com.springcore.value.component;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("obj")
public class Man {
	@Value("Akash")
	private String name;
	@Value("223222")
	private int mno;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMno() {
		return mno;
	}
	public void setMno(int mno) {
		this.mno = mno;
	}
	@Override
	public String toString() {
		return "Man [name=" + name + ", mno=" + mno + "]";
	}

}
