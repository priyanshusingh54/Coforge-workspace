package com.springcore.value.component;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		
		// Man
		
		ApplicationContext context=new ClassPathXmlApplicationContext("com/springcore/value/component/config.xml");
		Man man=(Man) context.getBean(Man.class);
		System.out.println(man);
		
		System.out.println("+++++++++++++++++++++++++++++");
		
		
		
		ApplicationContext context1=new ClassPathXmlApplicationContext("com/springcore/value/component/config.xml");
		Man2 man2=(Man2) context1.getBean(Man2.class);
		System.out.println(man2.getAddress());
	}

}
