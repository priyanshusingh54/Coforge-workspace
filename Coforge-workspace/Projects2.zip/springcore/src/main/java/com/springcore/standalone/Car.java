package com.springcore.standalone;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

//import org.springframework.beans.factory.annotation.Autowired;

public class Car {
	
	
	private List<String> model;
	private Map<String, Integer> price;
	private Set<Integer> year;
	public List<String> getModel() {
		return model;
	}
	public void setModel(List<String> model) {
		this.model = model;
	}
	public Map<String, Integer> getPrice() {
		return price;
	}
	public void setPrice(Map<String, Integer> price) {
		this.price = price;
	}
	
	public Set<Integer> getYear() {
		return year;
	}
	public void setYear(Set<Integer> year) {
		this.year = year;
	}
	@Override
	public String toString() {
		return "Car [model=" + model + ", price=" + price + ", year=" + year + "]";
	}

	
	
	
	
}
