package com.springcore.standalone;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/springcore/standalone/config.xml");
		Car cars=(Car) context.getBean("car1",Car.class);
		
		System.out.println(cars);
		System.out.println(cars.getModel().getClass().getName());
		System.out.println("+++++++++++++++++++++++++++++++++");
		System.out.println(cars.getPrice());
		System.out.println("+++++++++++++++++++++++++++++++++");
		System.out.println(cars.getYear());
	}
}