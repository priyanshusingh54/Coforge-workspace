package com.coforge.training.inventory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.coforge.training.inventory.model.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {

	/*JPARepository  contains API for basic CRUD operations and 
	 * also API for pagination and sorting.*/
	
	//This interface has save(),findAll(),findById(),deleteById(),count()
    //etc.. inbuilt methods of jpa repository for various db operations.
    // This interface will be implemented by class automatically
}
