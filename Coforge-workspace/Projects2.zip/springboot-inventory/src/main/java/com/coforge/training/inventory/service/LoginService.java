package com.coforge.training.inventory.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coforge.training.inventory.model.Dealer;
import com.coforge.training.inventory.repository.DealerRepository;
import com.coforge.training.inventory.repository.UserRepository;

/*
@Service annotation is used with classes that provide some business functionalities.
It indicates that a class belongs to the Service layer.
*/
@Service

/*
The transactional annotation itself defines the scope of a single database transaction.
The database transaction happens inside the scope of persistence context.
*/

@Transactional
public class LoginService {
	
	/*
	@Autowired is one of the key annotation in annotation based Dependency Injection. */
	
    @Autowired
	private DealerRepository drepo;
    
    @Autowired
    private UserRepository urepo;
    
    public void saveDealer(Dealer dealer) {
        drepo.save(dealer);  // invokes save() method of JPA repo
    }
  
    public Dealer findByEmail(String email)
    {
                 return urepo.findByEmail(email);
        }
}
