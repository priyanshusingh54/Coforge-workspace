package com.coforge.training.inventory.repository;

import org.springframework.data.repository.CrudRepository;

import com.coforge.training.inventory.model.Dealer;

public interface UserRepository extends CrudRepository<Dealer, Long> {

	public Dealer findByEmail(String email);
}
