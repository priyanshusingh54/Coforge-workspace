package com.coforge.training.inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*@SpringBootApplication annotation, means this is the starting point for our Spring Boot application.
The main() method uses Spring Boot’s SpringApplication.run() method to launch an application.
*/
@SpringBootApplication
public class SpringbootInventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootInventoryApplication.class, args);
			
}}
