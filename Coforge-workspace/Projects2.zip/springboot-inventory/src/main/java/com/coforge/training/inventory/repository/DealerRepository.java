package com.coforge.training.inventory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.coforge.training.inventory.model.Dealer;

public interface DealerRepository extends JpaRepository<Dealer,Long> {
	
	//This interface has save(),findAll(),findById(),deleteById(),count()
    //etc.. inbuilt methods of jpa repository for various db operations.
    // This interface will be implemented by class automatically
}
