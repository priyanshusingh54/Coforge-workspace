package com.spring.core.jdbc.springjdbc2;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class App 
{
    public static void main( String[] args ){
    	
        System.out.println( "Hello World!" );
        ApplicationContext context=new ClassPathXmlApplicationContext("com/spring/core/jdbc/springjdbc2/config.xml");
        JdbcTemplate template = (JdbcTemplate) context.getBean("jdbcTemplate");
        String query="insert into student(id,name,city) values(?,?,?)";
        int update = template.update(query,598,"Anuj","Vanaras");
        System.out.println("inserted values"+update);
    }
}
