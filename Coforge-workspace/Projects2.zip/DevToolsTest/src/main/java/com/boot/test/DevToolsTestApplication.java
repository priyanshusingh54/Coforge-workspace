package com.boot.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication  // 3 use 1- auto configure 2- component scan and scan base package 3- enable annotations
public class DevToolsTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevToolsTestApplication.class, args);
	}

}
