package com.boot.test.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.boot.test.enties.Book;
import com.boot.test.repository.BookRepository;
import com.boot.test.service.BookService;

import jakarta.persistence.Id;

@RestController
public class TestController {
	
//	
//	@GetMapping("/books")
//	public Book getBook() 
//	
//	
//	{	Book book=new Book();
//		book.setId(213);
//		book.setTitle("The lion  big book");
//		book.setAuthor("Richard");
//		
//		return book ;
//	}
//	
	@Autowired
	private BookService bookService;
	
	@GetMapping("/books")
	public ResponseEntity< List<Book>>  getAllBook(Book book)
	{
		List<Book> all = this.bookService.getAllBooks();
		if(all.size()<=0)
		{
			return ResponseEntity.status(HttpStatus.CREATED).build();
		}
		else 
		{
			return ResponseEntity.ok(all);
		}
		
		
	}
	
	@GetMapping("books/{id}")
	//@ResponseBody
	public ResponseEntity<Book>  getBookById(@PathVariable("id") int id)
	{  
		Book book = this.bookService.getBookById(id);
		
		if (book==null) 
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}

		else
		{
			return ResponseEntity.ok(book);
		}
		
		
	}
	
	@PostMapping("books")
	public Book addBook(@RequestBody Book book) 
	{
		Book add = this.bookService.addBook(book);
		return add;
		
	}
	
	@DeleteMapping("books/{id}")

	public void deleteBook(@PathVariable("id")int id) 
	{
		this.bookService.getBookById(id);
		
	}
	public void updateBook(int bid) 
	{
		this.bookService.updateBook(bid); 
	}
	

}
