package com.boot.test.repository;

import org.springframework.data.repository.CrudRepository;

import com.boot.test.enties.Book;

public interface BookRepository  extends CrudRepository<Book, Integer>{
	
	public Book findById(int id);

}
