package com.boot.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.test.enties.Book;
import com.boot.test.repository.BookRepository;

@Service
public class BookService {
	
	@Autowired
	private BookRepository bookRepository;
	
	public List<Book> getAllBooks()
	{
		List<Book> list =(List<Book>) this.bookRepository.findAll();
		return list;
	}
	
	public Book getBookById(int id)
	{
		Book byId = bookRepository.findById(id);
		return byId;
	}
	
	public Book addBook(Book book) 
	{
		Book add = this.bookRepository.save(book);
		return add;
		
	}
	
	public void deleteBook(int id) 
	{
		this.bookRepository.deleteById(id);
		System.out.println("Successfully Deleted");
		
	}
	 
	public void updateBook(Book book, int bid) 
	{
		this.bookRepository.save(book);  
	}
	

}
