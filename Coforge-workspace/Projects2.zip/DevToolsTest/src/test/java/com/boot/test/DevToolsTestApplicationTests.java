package com.boot.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevToolsTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
