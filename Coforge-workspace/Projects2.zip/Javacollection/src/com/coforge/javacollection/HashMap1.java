package com.coforge.javacollection;

import java.util.HashMap;
import java.util.Map.Entry;

public class HashMap1 {

	public static void main(String[] args) {
		HashMap<Integer, String> hashMap = new HashMap<>();
		hashMap.put(04, " ");
		hashMap.put(3, " Sunny");
		hashMap.put(0, "Singh");
		hashMap.put(1, "Gautam");
		
		
		for(Entry<Integer,String> mpEntry:hashMap.entrySet())
		{
			System.out.println(mpEntry.getValue());
		}
		
		
		
		
	}

}
