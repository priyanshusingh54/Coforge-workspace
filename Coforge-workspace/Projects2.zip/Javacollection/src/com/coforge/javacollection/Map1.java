package com.coforge.javacollection;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Map1 {

	public static void main(String[] args) {
		Map<Integer, String> map = new HashMap<>();
		map.put(0, " ");
		map.put(1, "Akash ");
		map.put(3, "Gautam");
		map.put(4, "Priyanshu");
		
		
		for (Entry<Integer, String> me :map.entrySet()) 
		{
		
		
		System.out.println(me.getValue());
		}
			
		}
		
		

	

}
