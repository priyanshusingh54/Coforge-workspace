/**
 * 
 */
package com.coforge.javacollection;

import java.util.HashMap;
import java.util.Map.Entry;

public class HashMap2 {

	public static void main(String[] args) {
		HashMap<Integer, String> hashMap = new HashMap<>();
		hashMap.put(1, "Akash");
		hashMap.put(2, "Abhishek");
		hashMap.put(4, "Vikash");
		hashMap.put(3, "Arush");
		
		for(Entry<Integer, String> s:hashMap.entrySet())
		{
			System.out.println(s.getValue());
		}
		
	}

}
