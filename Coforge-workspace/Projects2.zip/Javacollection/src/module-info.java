module com.coforge.Javacollection {
}