package com.coforge.empmanagement.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

	public static Connection getDBConnection() {
		Connection conn=null;
		try {
			Class.forName("org.mariadb.jdbc.Driver");

			conn=DriverManager.getConnection("jdbc:mariadb://localhost:3306/Empoyees", "root", "akash@2302");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}

}
