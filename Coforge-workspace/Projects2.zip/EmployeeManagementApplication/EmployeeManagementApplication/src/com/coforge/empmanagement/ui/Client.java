package com.coforge.empmanagement.ui;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.coforge.empmanagement.model.Employee;
import com.coforge.empmanagement.service.EmployeeService;
import com.coforge.empmanagement.service.EmployeeServiceI;

//Presentation layer
public class Client {

	public static void main(String[] args) throws SQLException {
		int empId = 0;
		String empName = null;
		int empSal = 0;
		String empAdd = null;
		String message = null;

		EmployeeServiceI service = new EmployeeService();
		Scanner scan = new Scanner(System.in);
		System.out.println("*************Employee Management Application**********");
		System.out.println("1.Add Employee");
		System.out.println("2.Update Employee");
		System.out.println("3.Delete Employee");
		System.out.println("4.Get Employee");
		System.out.println("5.Get All Employees");
		System.out.println("6.Get All Employees InBetween");
		int option = scan.nextInt();
		switch (option) {
		case 1:
			System.out.println("Enter Employee Id:");
			empId = scan.nextInt();
			System.out.println("Enter Employee Name:");
			empName = scan.next();
			System.out.println("Enter Employee Salary:");
			empSal = scan.nextInt();
			System.out.println("Enter Employee Address:");
			empAdd = scan.next();
			Employee emp = new Employee(empId, empName, empSal, empAdd);// model object
			message = service.addEmployee(emp);
			System.out.println(message);
		case 2:
			System.out.println("Enter employee info to update ");
			System.out.println("Enter Your Exsisting Employee Id:");
			empId = scan.nextInt();
			System.out.println("Enter Employee Name :");
			empName = scan.next();
			System.out.println("Enter Employee Salary:");
			empSal = scan.nextInt();
			System.out.println("Enter Employee Address:");
			empAdd = scan.next();
			Employee emp1 = new Employee(empId, empName, empSal, empAdd);// model object
			message = service.updateEmployee(emp1);
			System.out.println(message);
		case 3:
			System.out.println("Enter employee info to Delete ");
			System.out.println("Enter Your Exsisting Employee Id:");
			empId = scan.nextInt();
			message = service.deleteEmployee(empId);
			System.out.println(message);
		case 4:
			System.out.println("Enter employee info to Get ");
			System.out.println("Enter Your Exsisting Employee Id:");
			empId = scan.nextInt();
			Employee emp2 = service.getEmployee(empId);
			System.out.println(emp2);
		case 5:
			ResultSet result = service.getAllEmployees();
			while (result.next()) {
				System.out.println(result.getInt(1) + " " + result.getString(2) + " " + result.getInt(3) + " "
						+ result.getString(4));
			}
		case 6:
			System.out.println("Enter employee info to Get ");
			System.out.println("Enter Your Intial salary");
			empSal = scan.nextInt();
			System.out.println("Enter Your Second salary");
			int empSal1 = scan.nextInt();
			ResultSet result1 = service.getAllEmployeesInBetween(empSal, empSal1);
			while (result1.next()) {
				System.out.println(result1.getInt(1) + " " + result1.getString(2) + " " + result1.getInt(3) + " "
						+ result1.getString(4));
			}

		}

	}

}
