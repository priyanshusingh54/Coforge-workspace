package com.coforge.empmanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.coforge.empmanagement.model.Employee;

public class EmployeeDAO implements EmployeeDAOI {
	Connection conn;
	int i = 0;

	public EmployeeDAO() {
		conn = DBConnection.getDBConnection();
	}

	@Override
	public String addEmployee(Employee emp) {

		try {
			PreparedStatement psmt = conn.prepareStatement("insert into employees values(?,?,?,?)");
			psmt.setInt(1, emp.getEmpId());
			psmt.setString(2, emp.getEmpName());
			psmt.setInt(3, emp.getEmpSal());
			psmt.setString(4, emp.getEmpAdd());
			i = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (i > 0)
			return "Employee Added Successfully....";
		else
			return "some issue";
	}

	@Override
	public String updateEmployee(Employee emp) {
		int j = 0;
		try {

			PreparedStatement psmt = conn.prepareStatement("update coforgeemps set ename=?,esal=?,eadd=? where eid=?");
			psmt.setString(1, emp.getEmpName());
			psmt.setInt(2, emp.getEmpSal());
			psmt.setString(3, emp.getEmpAdd());
			psmt.setInt(4, emp.getEmpId());
			j = psmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("error" + e);
		}
		if (j > 0)
			return "Employee updated Successfully....";
		else
			return "some issue";
	}

	@Override
	public String deleteEmployee(int empId) {
		int j = 0;
		try {
			PreparedStatement psmt = conn.prepareStatement("delete from coforgeemps where eid=?");
			psmt.setInt(1, empId);
			j = psmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("error" + e);
		}
		if (j > 0)
			return "Employee Deleted Successfully....";
		else
			return "some issue";
	}

	@Override
	public Employee getEmployee(int empId) {
		Employee emp = new Employee();
		try {
			PreparedStatement psmt = conn.prepareStatement("select * from coforgeemps where eid=?");
			psmt.setInt(1, empId);
			ResultSet result = psmt.executeQuery();
			result.next();
			emp.setEmpId(result.getInt(1));
			emp.setEmpName(result.getString(2));
			emp.setEmpSal(result.getInt(3));
			emp.setEmpAdd(result.getString(4));
		} catch (SQLException e) {
			System.out.println("error" + e);
		}
		return emp;
	}

	@Override
	public ResultSet getAllEmployees() {
		ResultSet result=null;
		try {
			PreparedStatement psmt = conn.prepareStatement("select * from coforgeemps");
			 result = psmt.executeQuery();
		} catch (SQLException e) {
			System.out.println("error" + e);
		}
		return result;
	}

	@Override
	public ResultSet getAllEmployeesInBetween(int intialSal, int sal) {
		ResultSet result=null;
		try {
			PreparedStatement psmt = conn.prepareStatement("select * from coforgeemps where esal between ? and ?");
			psmt.setInt(1, intialSal);
			psmt.setInt(2, sal);
			 result = psmt.executeQuery();
		} catch (SQLException e) {
			System.out.println("error" + e);
		}
		return result;
	}

}
