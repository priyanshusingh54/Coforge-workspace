package com.coforge.empmanagement.exceptions;

public class EmployeeIdNotFoundException extends Exception {
	public EmployeeIdNotFoundException(String message) {
		super(message);
	}
}
