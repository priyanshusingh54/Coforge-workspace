package com.coforge.empmanagement.service;

import java.sql.ResultSet;

import com.coforge.empmanagement.dao.EmployeeDAO;
import com.coforge.empmanagement.dao.EmployeeDAOI;
import com.coforge.empmanagement.model.Employee;

public class EmployeeService  implements EmployeeServiceI{
	EmployeeDAOI dao=new EmployeeDAO();
	@Override
	public String addEmployee(Employee emp) {
	
		return dao.addEmployee(emp);
	}

	@Override
	public String updateEmployee(Employee emp) {
		
		return dao.updateEmployee(emp);
	}

	@Override
	public String deleteEmployee(int empId) {
	
		return dao.deleteEmployee(empId);
	}

	@Override
	public Employee getEmployee(int empId) {
		
		return dao.getEmployee(empId);
	}

	@Override
	public ResultSet getAllEmployees() {
		
		return dao.getAllEmployees();
	}

	@Override
	public ResultSet getAllEmployeesInBetween(int intialSal, int sal) {
		// TODO Auto-generated method stub
		return dao.getAllEmployeesInBetween(intialSal, sal);
	}

}
