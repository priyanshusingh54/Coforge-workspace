package com.coforge.empmanagement.service;

import java.sql.ResultSet;

import com.coforge.empmanagement.model.Employee;

public interface EmployeeServiceI {
	public abstract String addEmployee(Employee emp);

	public abstract String updateEmployee(Employee emp);

	public abstract String deleteEmployee(int empId);

	public abstract Employee getEmployee(int empId);

	public abstract ResultSet getAllEmployees();

	public abstract ResultSet getAllEmployeesInBetween(int intialSal, int sal);
}
