package com.boot.jpa;

import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import com.boot.jpa.dao.UserRepository;
import com.boot.jpa.enties.User;

@SpringBootApplication
public class BootJpaApplication {

	public static void main(String[] args) {
	
		
		ApplicationContext context = SpringApplication.run(BootJpaApplication.class, args);
		UserRepository userRepository = context.getBean(UserRepository.class);
		
//		User user1= new User();
//		
//		user1.setName("Akash");
//		user1.setCity("Delhi");
//		user1.setAddress("Azadpur");
//		user1.setStatus("Sign in..");
//		User save1 = userRepository.save(user1);
//		System.out.println("Hello world my file is successfully running....");
//		System.out.println(save1);
//		
//		User user2= new User();
////		
//		user2.setName("Akshay");
//		user2.setCity("Mumbai");
//		user2.setAddress("Town");
//		user2.setStatus("Sign off..");
//		List<User> list = List.of(user1,user2);
//		Iterable<User> saveAll = userRepository.saveAll(list);
//		list.forEach(e->System.out.println(e));
//		
//		System.out.println("Hello world my file is successfully running....");
//		System.out.println(saveAll);
//		
		User user=new User();
		
//		Optional<User> optional = userRepository.findById(452);
//		User users = optional.get();
//		users.setName("Amit Yadav");
//		User save = userRepository.save(users);
//		System.out.println(save);
//		userRepository.deleteAll();
		
		// Get All Users
		
//		 List<User> name = userRepository.findByName("Akshay");
//		 name.forEach(u->System.out.println(u));
//		List<User> allUsers = userRepository.getAllUsers();
//		allUsers.forEach(e->System.out.println(e));
		
		List<User> userByName = userRepository.getUserByName("Akash","Delhi");
		userByName.forEach(e->System.out.println(e));
			
		}
		
	}


