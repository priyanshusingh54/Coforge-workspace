package com.boot.jpa.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.boot.jpa.enties.User;

public interface UserRepository extends CrudRepository<User, Integer>{
	public List<User> findByName(String name);
	
	@Query("select u from User u")  // @Query is use for fetching data with db
	public List<User> getAllUsers();
	
	@Query("select u from User u WHERE u.name =:n")
	public List<User> getUserByName(@Param("n") String name);  // @Param are use to for bind the data with name in db

	@Query("select u from User u WHERE u.name =:n and u.city =:c")
	public List<User> getUserByName(@Param("n") String name, @Param("c") String city);  // @Param are use to for bind the data with name in db

	

}
