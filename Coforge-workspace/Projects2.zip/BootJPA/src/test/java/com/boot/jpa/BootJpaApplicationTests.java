package com.boot.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
