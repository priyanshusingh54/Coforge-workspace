package com.coforge.java;

public class ToCheck {
	
	

	public static void main(String[] args) {
		String st="This is my name";
		int length = st.length();
		String[] sp = st.split("s");
		for(String s:sp) {
			System.out.println(s);
		}
		System.out.println(length);
		System.out.println();

	}

}
