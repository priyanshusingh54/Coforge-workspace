package com.coforge.java;

import java.util.Scanner;

public class PolidromeNo {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int num=121,rev=0,temp,sum;
		temp=num;
		while (num!=0)
		{
			rev=rev*10+num/10;
			num=num/10;
		}
		
		if (num==rev)
		{
			System.out.println("Polidrome no");
		}
		
		else
		{
			System.out.println("Not");
		}
		
	}

}
