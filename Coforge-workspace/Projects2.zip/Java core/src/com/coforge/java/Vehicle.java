package com.coforge.java;

class Car{
	void display()
	  {
		  System.out.println("Vehicle is running so Good");
		  }
}
	  
class Bike extends Car
	  {
	
	  }
	 
class Vehicle extends Car {
	  public static void main(String args[]){
	  Bike obj = new Bike();
	  Vehicle vehicle=new Vehicle();
	  vehicle.display();
	  obj.display();
	  }
}
	 
 