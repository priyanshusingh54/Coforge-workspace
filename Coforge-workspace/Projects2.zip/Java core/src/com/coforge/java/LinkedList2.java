package com.coforge.java;

import java.util.LinkedList;

public class LinkedList2 {

	public static void main(String[] args) {
		LinkedList<Integer>ll =new LinkedList<>();
		ll.add(5);
		ll.add(6);
		ll.add(5);
		ll.add(8);
		for(int d:ll)
			System.out.println(d);
		//System.out.println(ll);
	}

}
