package com.coforge.java;

import java.util.Scanner;

public class Polidrome3 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter your no");
		int num=scanner.nextInt();
		scanner.close();
		int temp=num;
		int rev=0;
		
		while(num>0) 
		{
			rev=rev*10+num%10;
			num=num/10;
		}
		if (temp==rev)
		{
			System.out.println("Polidrome no");
		}
		else
		{
			System.out.println("Not ploidrome no");
		}
		
	}

}
