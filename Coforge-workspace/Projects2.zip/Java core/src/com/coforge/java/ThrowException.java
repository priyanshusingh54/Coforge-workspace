package com.coforge.java;

public class ThrowException {
	
	static void check(int a, int b) 
	{
		if (b==0)
		{
			throw new ArithmeticException("bvc");
		}
		
		else {
			int c=a/b;
			System.out.println(c);
		}
	}

	public static void main(String[] args) {
		
		try 
		
		{
			check(20, 5);
			
		} 
		catch (Exception e) {
			System.out.println("This catch block");
		}
		
		
	}

}
