package com.coforge.java;

public class Test23 {
	public static void main(String[] args) {
		String st="This this is is done by Gautam Gautam";
		String[] split = st.split("\\ ");
		System.out.println(split);
	}

}
