package com.coforge.java;

import java.util.Scanner   ;

public class UserInput {
	public static void main(String[] args) {
		int a, b,c,d;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your First no =  ");
		a=sc.nextInt();
		
		System.out.println("Enter your 2nd no =  ");
		b=sc.nextInt();
		

		System.out.println("Enter your 3rd no =  ");
		c=sc.nextInt();
		
		sc.close();
		
		d=a+b+c;
		
		System.out.println("Sum of totall no=  "+d);
		
		
	}

}
