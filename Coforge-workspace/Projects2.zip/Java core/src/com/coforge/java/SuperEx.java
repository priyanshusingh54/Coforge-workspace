package com.coforge.java;

class Animal
 {
	String clour="white";
}
 
class Dog extends Animal{
	 
	 String clour="black"; 
	 
	 void Colorprint() 
	 {
		 System.out.println(clour);
		 System.out.println(super.clour);
     }
public class SuperEx {

	public static void main(String[] args) {
		Dog dog= new Dog();
		dog.Colorprint();

	}

}}
