package com.coforge.java;

import java.util.ArrayList;

public class ArrayList2 {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		al.add(7);
		al.add(8);
		al.add(9);
		al.add(7);
		
		for(int b : al)
			System.out.println(b);
		System.out.println(al);
	}

}
