package com.coforge.java;

public class Reverse2 {

	public static void main(String[] args) {
		String st = "abcd";
		String rev = "";
		char a[]=st.toCharArray();
		for(int i=a.length-1;i>=0;i--)
		{
			rev=rev+a[i];
		}
		System.out.println(rev);
	}

}
