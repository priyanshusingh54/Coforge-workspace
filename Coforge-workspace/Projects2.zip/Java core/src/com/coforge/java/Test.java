package com.coforge.java;

class Test2 extends Exception{
	
	public Test2(String msg)
	{
	System.out.println(msg);
	}
}	
public class Test{
	static void tocheck(String st1, String st2) throws Test2
	{
		if(!st2.contains(st1)) 
		{
			throw new Test2("Not found");
		}
		else {
			System.out.println("Found");
		}
	}

	
	public static void main(String[] args) 
	{
		try 
		{
			tocheck("sh", "Akash");
		}
		catch (Exception e) {
			System.out.println(e);
		}
	}
	}
