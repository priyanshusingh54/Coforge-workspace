package com.coforge.java;

public class Array {

	public static void main(String[] args) {
		int a[]= new int[4]; // way 1 to declare array
		a[0]=10;
		a[1]=20;
		a[2]=30;
		
		int b[]= {2,4,6,8};//way 2 to declare array
		int c[][]= {{9,8},{23,4}};
				
		
		System.out.println(a[2]);
		System.out.println(c);
		
		b[3]=5;
		System.out.println(b[2]);
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
			System.out.println(i);
			
		}
	}

}
