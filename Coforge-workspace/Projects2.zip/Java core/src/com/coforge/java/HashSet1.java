package com.coforge.java;

import java.util.HashSet;

public class HashSet1 {

	public static void main(String[] args) {
		HashSet<Integer> hs = new HashSet<Integer>();
		hs.add(5);
		hs.add(1);
		hs.add(0);
		hs.add(4);
		hs.add(4);
		
		for(int i:hs)
		{
			System.out.println(i);
		}
		
	}

}
