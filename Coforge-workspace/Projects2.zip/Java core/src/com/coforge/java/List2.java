package com.coforge.java;

import java.util.ArrayList;
import java.util.List;

public class List2 {

	public static void main(String[] args) {
		List<Integer> li = new ArrayList<>();
		li.add(3);
		li.add(6);
		li.add(8);
		//li.remove(2);
		
		for(int a:li)
			System.out.println(a);
		
		System.out.println(li);
		
	}

}
