package com.coforge.java;

import java.util.Scanner;

public class Reverse3 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String a = scanner.nextLine();
		scanner.close();
		String reverse ="";
		char b[]=a.toCharArray();
		for(int i=b.length-1;i>=0;i--) 
		{
			reverse=reverse+b[i];
		}
		System.out.println(reverse);
			
		
	}

}
