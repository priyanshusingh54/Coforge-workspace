package com.coforge.java;

import java.util.Scanner;

public class Odd {
	public static void main(String[] args) {
	System.out.println("Enter your no : ");
	Scanner sc = new Scanner(System.in);
	int num = sc.nextInt();
	sc.close();
	if(num % 2 == 0) {
        System.out.println(num + " is even");
    }
    else
    
        System.out.println(num+" is odd");
	}

}
