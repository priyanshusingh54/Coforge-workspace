package com.coforge.java;

import java.util.Scanner;

public class Reverse1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your String to check =  ");
		String a = sc.nextLine();
		sc.close();
		String rev = " ";
		char b[]= a.toCharArray();
		for(int i=b.length-1;i>=0;i--)
		{
			rev=rev+b[i];
		}
		
		System.out.print(rev);
	}

}
