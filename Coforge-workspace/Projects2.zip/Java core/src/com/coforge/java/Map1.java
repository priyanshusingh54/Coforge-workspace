package com.coforge.java;

import java.util.HashMap;
import java.util.Map;

public class Map1 {

	public static void main(String[] args) {
		Map<String, String> mp = new HashMap<>();
		mp.put("Actor", "Amir khan");
		mp.put("Book", "Chemistry");
		mp.put("Taste", "sweet");
		mp.put("Actress", "Alia");
		mp.put("Show", "CID");
		
		System.out.println(mp);
		
		mp.keySet();
		
//		
		mp.equals(mp);
		
//		
		for (Map.Entry<String, String> me :mp.entrySet()) 
		{
		
		
		System.out.println(me.getValue());
		}

//		System.out.println(mp);

		
	}

}
