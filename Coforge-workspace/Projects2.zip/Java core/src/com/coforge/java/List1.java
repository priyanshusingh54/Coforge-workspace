package com.coforge.java;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class List1 {
	

	public static void main(String[] args) {
		List<Integer> li = new ArrayList<>();
		li.add(8);
		li.add(6);
		li.add(6);
		li.add(60);
	
		//Iterator itr=li.iterator();  
		
		for(int s:li)
		{
			System.out.println(s);
		}
		
		System.out.println(li);
		
		System.out.println(li.isEmpty());
		li.remove(1);
		System.out.println(li);
		
		
	}

}
