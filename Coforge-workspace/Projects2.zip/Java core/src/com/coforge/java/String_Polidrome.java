package com.coforge.java;

import java.util.Scanner;

public class String_Polidrome {

	public static void main(String[] args) {
		
		String org,rev = "";
		Scanner scanner=new Scanner(System.in);
		org=scanner.nextLine();
		scanner.close();
		int length=org.length();		
		
		for(int i=length-1;i>=0;i--) 
			rev=rev+org.charAt(i);
			
			if (org.equals(rev)) {
			System.out.println("Plidrome String");
			}
			else {
				System.out.println("Not Polidrone String");
			}
			
	}

}
