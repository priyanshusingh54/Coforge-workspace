package com.coforge.java;

public class Substract {

	public static void main(String[] args) {
		int a=20,b=12,c;
		c=a-b;
		System.out.println("Substraction of two no ="+""+ c);
	}

}
