package com.coforge.java;

public class Multiplication {
	public static void main(String[] args) {
		int a=20,b=12,c;
		c=a*b;
		System.out.println("Multiplication of two no ="+""+ c);

}}
