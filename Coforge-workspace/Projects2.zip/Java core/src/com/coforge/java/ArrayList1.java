package com.coforge.java;

import java.util.ArrayList;

public class ArrayList1 {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		
		
		al.add(2);
		al.add(3);
		al.add(1);
		al.add(97);
		
		
		System.out.println(al);
		
		for(Integer s:al)
		{
			System.out.println(s);
		}
		
		
		
		System.out.println(al);
	
		
		
		
	}

}
