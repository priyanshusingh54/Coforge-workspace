package com.coforge.java;

import java.util.LinkedList;

public class LinkedList1 {

	public static void main(String[] args) {
		LinkedList<Integer> link = new LinkedList<>();
		link.add(5);
		link.add(4);
		for(int s:link)
		{
			System.out.println(s);
		}
		System.out.println(link);
	}

}
