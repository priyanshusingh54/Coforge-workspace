package com.coforge.java;

public class ThrowEx {
	
		void checkage(int age)
	{
		if (age<20) 
		{
			throw new ArithmeticException("You are not eligible");
		}
		
		else {
			System.out.println("you are eligible");
		}
	
	}

	public static void main(String[] args) {
		
		ThrowEx sThrowEx1 = new ThrowEx();
		sThrowEx1.checkage(15);
		
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
