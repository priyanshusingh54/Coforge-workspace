package com.coforge.java;

public class Division {
	public static void main(String[] args) {
		
		int a=20,b=3,c;
		c=a%b;
		System.out.println("Division of two no ="+""+ c);
		

}}

