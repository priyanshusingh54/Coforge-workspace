package com.coforge.java;

public class MethodOverride {
void run()
	{
		System.out.println("Running");
	}}
	
class MethodOverride2 extends MethodOverride {
		

	public static void main(String[] args) {
		MethodOverride2 obj = new MethodOverride2();
		obj.run();
	
	}

}
