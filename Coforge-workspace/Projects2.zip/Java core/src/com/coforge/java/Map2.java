package com.coforge.java;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Map2 {

	public static void main(String[] args) {
		Map<Integer, String> mp3=new HashMap<>();
		mp3.put(1, "aakash");
		//mp3.get(mp3);
		
		for (Entry<Integer, String> m:mp3.entrySet()){
			System.out.println(m.getKey());
		}

	}

}
