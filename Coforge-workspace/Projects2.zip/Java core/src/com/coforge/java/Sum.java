package com.coforge.java;

import java.util.Scanner;

public class Sum {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your 1st no " + "\n");
		int num1 = sc.nextInt();
		
		System.out.println("Enter your 2nd no " + "\n");
		int num2 = sc.nextInt();
		sc.close();
		int num;
		num = num1+num2;
		System.out.println(num);
		
		
		
		
	}
}
