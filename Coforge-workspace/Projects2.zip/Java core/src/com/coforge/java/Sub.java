package com.coforge.java;

public class Sub {
	public static void main(String args[])
	{
		int a=4,b=5,c;
		c=b-a;
		System.out.println(c);
	}

}
