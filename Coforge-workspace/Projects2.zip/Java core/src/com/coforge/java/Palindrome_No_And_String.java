package com.coforge.java;

import java.util.Scanner;

class Palindrome_No_And_String  
{  
   public static void main(String args[])  
   {  
      String original, reverse = ""; // Objects of String class  
      Scanner ins = new Scanner(System.in);   
      System.out.println("Enter a string/number to check if it is a palindrome");  
      original = ins.nextLine();
      ins.close();
      int length = original.length();   
      for ( int i = length - 1; i >= 0; i-- )  
         reverse = reverse + original.charAt(i);  
      if (original.equals(reverse))  
         System.out.println("Polidrome");  
      else  
         System.out.println("Not Polidrome");   
   }  
}  