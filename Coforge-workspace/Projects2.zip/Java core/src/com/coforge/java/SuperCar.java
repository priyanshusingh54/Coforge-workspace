package com.coforge.java;


public class  SuperCar extends Car{
	
	class Car{
		void display() {
			System.out.println("This is Car");
		}
	}
	public static void main(String arg[]) {
		
	}
	
}
