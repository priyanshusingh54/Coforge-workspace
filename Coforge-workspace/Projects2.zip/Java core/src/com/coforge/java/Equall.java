package com.coforge.java;

import java.util.Scanner;

public class Equall {

	public static void main(String[] args) {
		System.out.println("Enter your 1st no =: ");
		Scanner scanner = new Scanner(System.in);
		int num = scanner.nextInt();
		scanner.close();
		if (num%2==0)
		
		{
		 System.out.println(num+ " " + "Even No");
		 
		}
		
		else {
			System.out.println(num + "   " + "Odd");
		}
		
	}

}
