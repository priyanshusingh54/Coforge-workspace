package com.coforge.java;

public class ConstractorEX {
	//String a;
	
	ConstractorEX(String abcd)
	
	{
		String a=abcd;
		System.out.println(a);
	}		
	void display() {
		System.out.println("hello");
	}
	

	public static void main(String[] args) {
		ConstractorEX c = new ConstractorEX("Avc");
		ConstractorEX c2 = new ConstractorEX("abcsstyufui");
		ConstractorEX cd = new ConstractorEX("");
		
		/*System.out.println(c);
		System.out.println(c2);
		System.out.println(cd);*/
		
		c.display();
		
		
	}
	
	

}
