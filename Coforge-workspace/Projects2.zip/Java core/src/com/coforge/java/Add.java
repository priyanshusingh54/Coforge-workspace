package com.coforge.java;
/*public class Add {

	   public static void main(String[] args) {
	        
	      int a = 5, b = 15, c;
	      c = a + b;

	      System.out.println(c);
	   }
	}
	
	#Type 2
	
	
    public class Add {
    	public static void main(String[] args) {
    		int a = 3, b = 7, c;
    		c = a + b;
    		
    		System.out.println(c);
    		
			
		}
    } */
public class Add {
	public static void main(String[] args) {
		int a = 3;
		int b = 77;
		int c;
		c = a + b;
		
		System.out.println(c);
		
		
	}}

