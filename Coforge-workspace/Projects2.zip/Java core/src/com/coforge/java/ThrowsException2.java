package com.coforge.java;

class StringNotMatchException extends Exception{
	
	StringNotMatchException(String msg) 
	{
		System.out.println(msg);
	}
		
	}


public class ThrowsException2 {
	
	
	static void check(String a, String b) throws StringNotMatchException
	
	{
		if (!b.contains(a)) 
		{
			throw new StringNotMatchException("Not Found");
		}
	
		else {
			System.out.println("found");
		}
	}

public static void main(String[] args) 
	{
		try 
		{
			check("lo", "hello");
		} 
		catch (Exception e) 
		{
			System.out.println(e);
		}
	}

}
