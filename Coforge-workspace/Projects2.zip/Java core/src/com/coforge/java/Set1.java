package com.coforge.java;

import java.util.HashSet;
import java.util.Set;

public class Set1 {

	public static void main(String[] args) {
		Set<Integer> st = new HashSet<Integer>();
		//Set is a Interface so it implement a class (HashSet)
		
		/*st.add(2);
		st.add(4);
		st.add(1);
		st.add(0);
		
		
		//System.out.println(st);
		for(Integer a:st) {
			System.out.println(a);
		}
		//st.remove(2);
		System.out.println(st);  */
		
		System.out.println((st.add(5)));
		System.out.println((st.add(3)));
		System.out.println((st.add(0)));
		System.out.println((st.add(4)));
		
		for(int i:st) 
		{
			System.out.println(i);
		}
		
		}
		
	}


