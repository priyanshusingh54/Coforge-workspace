module com.coforge.java {
}