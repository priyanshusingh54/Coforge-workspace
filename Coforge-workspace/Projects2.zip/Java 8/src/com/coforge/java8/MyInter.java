package com.coforge.java8;

public class MyInter implements Inter {

	@Override
	public void hello() {
		
	}

	

}
