package com.coforge.java8;

@FunctionalInterface
public interface Inter {
	public abstract void hello();
	
	
	
	

}
