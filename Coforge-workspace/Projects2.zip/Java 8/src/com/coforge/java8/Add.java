package com.coforge.java8;

public interface Add  {
	
	public abstract  int sum(int a, int b); 
}
