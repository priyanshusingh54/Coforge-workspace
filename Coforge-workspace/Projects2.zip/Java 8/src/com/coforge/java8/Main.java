package com.coforge.java8;

public class Main {
	
	public void hello() {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) {
//		MyInter pinter = new MyInter();
		
		Add add = (a,b) -> a+b ;
				
				System.out.println(add.sum(2, 3));
			
		
		
		
	}

}
