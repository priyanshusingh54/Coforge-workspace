package com.boot.empmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.empmanagement.entity.Employee;
import com.boot.empmanagement.repository.EmpRepository;

@Service
public class EmpService {

	@Autowired
	private EmpRepository repository;
	public void addEmp(Employee e) 
	{
		repository.save(e);
	}
	
	public List<Employee> getAllEmp()
	{
		return repository.findAll();
	} 
	
}
