package com.boot.thymeleaf.controller;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MyController {
	
	@GetMapping("/about")
	public String about(Model model ) 
	{
		model.addAttribute("name","Akash");		model.addAttribute("sex", "male");
		model.addAttribute("date",new Date().toString());
		System.out.println("Inside the controller");
		return "about";
		// about.html
	}
	
	@GetMapping("/iterate")
	public String iterateHandler( Model m) 
	{
		// Creating a list
		
		List<String> names = List.of("Akash","vikash","Chandu","Vinay");
		m.addAttribute("name", names);
		return "iterate";	
	}
	
	@GetMapping("/condition")
	public String conditionHandler(Model m2) 
	{
		m2.addAttribute("isActive",true);
		m2.addAttribute("gender", "M");
		
		List<Integer> list = List.of(3,4,5,6,7,8,9,7);
		
		m2.addAttribute("mylist", list);
		return "condition";
	}
	
	//Handler for including fragments
	
	@GetMapping("/services")
	public String servicesHandler(Model m3) 
	{
		m3.addAttribute("title","I want to learn java");
		m3.addAttribute("subtitle",LocalDateTime.now().toString());
		return "services";
	}
	
	// handler for about new 
	@GetMapping("/aboutnew")
	public String aboutNew() 
	{
		return "aboutnew";
	}
	
	@GetMapping("/contact")
	public String contact() 
	{
		return "aboutnew";
	}

}
