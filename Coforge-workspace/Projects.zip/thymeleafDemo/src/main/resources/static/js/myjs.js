console.log("This is message by console")
alert("Please fill form creectlly")