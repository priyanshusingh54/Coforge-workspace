package com.boot.contact.manger.controller;

public class MyController {

}
