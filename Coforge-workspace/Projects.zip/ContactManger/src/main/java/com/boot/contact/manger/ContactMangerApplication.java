package com.boot.contact.manger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactMangerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContactMangerApplication.class, args);
	}

}
