package com.boot.demo1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.boot.demo1.helper.FileUploadHelper;

@RestController
public class FileUploadController {
	
	@Autowired
	private FileUploadHelper fileUploadHelper;
	
	@PostMapping("/file-upload")
	public ResponseEntity<String> fileUpload(@RequestParam("file") MultipartFile file )
	{
//		System.out.println(file.getName());
//		System.out.println(file.getSize());
//		System.out.println(file.getContentType());
//		return ResponseEntity.ok("Working...");
//
		try
		{
		if(file.isEmpty()) 
		{
			ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Must contain a file");
		}
		
		if(!file.getContentType().equals("image/jpeg"))
		{
		   return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("only jpeg file are allowed");
		}
		
		boolean b = fileUploadHelper.uploadfile(file);
		
		if (b) 
		{
		  // return ResponseEntity.ok("file upload successfully");	
			
			return ResponseEntity.ok(ServletUriComponentsBuilder.fromCurrentContextPath().path("image/").path(file.getOriginalFilename()).toUriString());
		}
		
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
		 return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("somthing went wrong");
		
	}
	
	
}
