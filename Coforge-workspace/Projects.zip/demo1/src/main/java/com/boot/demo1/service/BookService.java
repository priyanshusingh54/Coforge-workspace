package com.boot.demo1.service;



import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.demo1.dao.BookRepository;
import com.boot.demo1.entities.Book;


@Service
public class BookService {
	
//    private static List<Book> list=new ArrayList<Book>();
//    static 
//    {
//        list.add(new Book(121,"John","Team"));
//        list.add(new Book(122,"Rock","Varoso"));
//        list.add(new Book(123,"Tom","Domin"));
//    }
	
	@Autowired
	private BookRepository bookRepository;
	
	

    public List<Book> getAllBook()
     { 
    	List <Book> list = (List<Book>) this.bookRepository.findAll();
         return list;
    }

    public Book getBookById(int id)
    {
        Book book=null;
        try{
        //book=list.stream().filter(e->e.getId()==id).findFirst().get();
        	
        	book = this.bookRepository.findById(id);
        	
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return book;
    }
    
    public Book addBook(Book b)
    {
        Book save = this.bookRepository.save(b);
        return save;
    }

    public void removeBook(int bid)
    {
        //list.stream().filter(book->book.getId()!=bid).collect(Collectors.toList());
    	bookRepository.deleteById(bid);;
    	System.out.println("Deleted successfully");
    }

    public void updateBook(int bid , Book book)
    {
//        list.stream().map(b->
//        {
//            if(b.getId()==bid)
//            {
//                b.setAuthor(book.getAuthor());
//                b.setTitle(book.getTitle());
//            }
//            
//          return b;
//            
//        }).collect(Collectors.toList());
    	
    	book.setId(bid);;
    		bookRepository.save(book);
    	
    }
}
