package com.coforge.StreamAPI;

import java.util.List;

public class Test {
    public static void main(String[] args) {
        List<Integer>list=List.of(2,3,4,5);
        List list1=list.stream().filter(a->a%2!=0).toList();


        System.out.println(list1);

    }

}
