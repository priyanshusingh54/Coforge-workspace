package com.coforge.StreamAPI;

import java.util.List;

import static java.util.stream.Collectors.toList;

public class EvenAndOdd {
    public static void main(String[] args) {
        List<Integer> list =List.of(2,3,5,4,8,10);

        System.out.println(list);

        // Method 1-> using collect and collections without import
        // stream.Collectors.toList

        List<Integer>li=list.stream().filter(a->a%2==0).collect(toList());


        System.out.println("Its even list"+li);

        // Method 2-> Without using of .collect(toList()); and import
        //.collect(toList());

        List<Integer>li2=list.stream().filter(a->a%2!=0).toList();

        System.out.println("Its odd list"+li2);

    }

}
