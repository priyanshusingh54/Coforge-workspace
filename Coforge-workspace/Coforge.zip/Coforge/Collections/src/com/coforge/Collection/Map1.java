package com.coforge.Collection;

import java.util.HashMap;
import java.util.Map;

public class Map1 {
    public static void main(String[] args) {
        Map<Integer,String> map= new HashMap<>();
        map.put(2,"abc");
        System.out.println(map.get(map));

    }
}
