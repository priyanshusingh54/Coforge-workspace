package com.coforge.Collection;

import java.util.HashMap;
import java.util.Map;

public class Map2 {
    public static void main(String[] args) {
        Map<Integer,String> map = new HashMap<>();
        map.put(12,"Akash");
        map.put(13,"Sunny");
        System.out.println(map.entrySet());
        for (Map.Entry<Integer,String> s:map.entrySet())
        {
            System.out.println(s.getValue());
        }
    }
}
