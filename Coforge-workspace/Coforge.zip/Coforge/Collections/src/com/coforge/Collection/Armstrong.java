package com.coforge.Collection;

import java.util.Scanner;

public class Armstrong {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int num= scanner.nextInt();
        int temp=num;
        int arm=0;
        int rem;

        while (num>0)
        {
            rem=num%10;
            arm=(rem*rem*rem)+arm;
            num=num/10;
        }
        if (temp==arm)
        {
            System.out.println("Armstrong");
        }
        else
        {
            System.out.println("Not Armstrong");
        }
        }
}
