package com.coforge.Collection;

//import java.util.ArrayList;


import java.util.ArrayList;
import java.util.List;


public class List1 {
    public static void main(String[] args) {
    List<Integer> list=new ArrayList<Integer>();
    list.add(2);
    list.add(3);
    list.add(5);
    list.add(4);

        System.out.println(list);

        for (int s:list
             ) {
            System.out.println(s);
        }

    }
}
