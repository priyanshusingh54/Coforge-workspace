package com.coforge.Collection;

import java.util.List;

public class Test2 {
    public static void main(String[] args) {
        List<Integer>list=List.of(2,4,5,6,7);
        System.out.println(list);

        List<Integer>li=list.stream().filter(a->a%2==0).toList();
        System.out.println(li);

        for (int s:list)
        {
            System.out.println(s);
        }
    }


}
