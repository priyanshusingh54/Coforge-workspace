package com.coforge.Lambda;

public class T2 {
    public static void main(String[] args) {
        T1 t1=(a, b) -> a+b;
       System.out.println(t1.sum(2,6));
       System.out.println(t1.sum(23,62));
    }
}
