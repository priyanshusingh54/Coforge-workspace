package com.coforge.Lambda;

public interface Length {
    int length(String st);
}
