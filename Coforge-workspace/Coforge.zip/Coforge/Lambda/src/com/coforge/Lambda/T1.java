package com.coforge.Lambda;

public interface T1 {
    int sum(int a,int b);
}
