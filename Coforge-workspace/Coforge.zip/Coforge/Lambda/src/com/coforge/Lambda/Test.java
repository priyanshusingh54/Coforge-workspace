package com.coforge.Lambda;
@FunctionalInterface
 interface Test {
   public abstract int add(String str);


}
