package com.coforge.Lambda;
@FunctionalInterface
public interface Sum {
    int add(int a, int b);
}
