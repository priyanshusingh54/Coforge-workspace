package com.coforge.Lambda;

public class MySum{
    public static void main(String[] args) {
        Sum sum = (a,b)-> a+b;
        System.out.println(sum.add(2,3));
        System.out.println(sum.add(9,9));
    }
    }

