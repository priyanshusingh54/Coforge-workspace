package com.coforge.Lambda;

public class MyDrawable{

    public static void main(String[] args) {

        int width=10;

        Drawable drawable=()->{
           System.out.println("width :  " + width);

        };
        drawable.Fun();
    }
}
