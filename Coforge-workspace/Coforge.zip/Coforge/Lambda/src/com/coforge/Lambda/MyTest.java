package com.coforge.Lambda;

public class MyTest {
    public static void main(String[] args) {

       Test test=(str -> str.length());
        System.out.println(test.add("Akash"));


    }

}
