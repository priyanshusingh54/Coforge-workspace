package com.coforge.Lambda;
@FunctionalInterface
interface Team{
    void sum();

}
public class Test23 {
    public static void main(String[] args) {
        Team team=()->{
            System.out.println("hiii");
        };
        team.sum();
    }
}
