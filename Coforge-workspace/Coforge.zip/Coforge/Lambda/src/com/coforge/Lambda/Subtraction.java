package com.coforge.Lambda;

public interface Subtraction {
     int sub(int a, int b);
}
