package com.coforge.Lambda;

public class MyLength{

    public static void main(String[] args) {
        Length length1=(st -> st.length());
       // System.out.println(length1.length("Akash"));
    }

}
