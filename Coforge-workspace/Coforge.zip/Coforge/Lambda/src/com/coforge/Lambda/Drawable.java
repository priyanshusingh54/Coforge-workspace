package com.coforge.Lambda;

public interface Drawable {
    void Fun();
}
