package com.coforge.Lambda;

//class Sub implements Subtraction{
//    public int sub(int a, int b){
//        return a+b;
//    }
//}
public class MySubtraction {
    public static void main(String[] args) {
        Subtraction subtraction=(a, b) -> a-b;
        System.out.println(subtraction. sub(2,8));

    }
}
