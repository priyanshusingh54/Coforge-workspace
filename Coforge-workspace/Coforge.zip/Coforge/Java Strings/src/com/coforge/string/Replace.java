package com.coforge.string;

public class Replace {
    public static void main(String[] args) {
        String s="My name is akash";
        System.out.println(s.replace("a","A"));// replace the char


    }
}
