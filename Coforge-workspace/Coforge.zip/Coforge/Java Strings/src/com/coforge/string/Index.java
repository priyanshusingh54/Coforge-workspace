package com.coforge.string;

import java.util.Scanner;

public class Index {
    public static void main(String[] args) {
//        String s= "Akash";
//        System.out.println(s.indexOf("a"));
//        System.out.println(s.lastIndexOf("Akash"));
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String sentence = scanner.nextLine();
        String[] words = sentence.split(" ");
        System.out.println("The words in the sentence are:");
        for (String word : words) {
            System.out.println(word);
        }
    }}
