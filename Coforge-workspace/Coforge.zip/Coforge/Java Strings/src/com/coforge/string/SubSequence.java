package com.coforge.string;

public class SubSequence {
    public static void main(String[] args) {
    String s="This is my home and i will never left my home";
        System.out.println(s.subSequence(3,6));// o/p index 1, index 2  (char[])

        System.out.println(s.substring(3,6));//same output but (String)
        System.out.println(s.substring(2));//  till to end output but (String)
    }
}
