package com.coforge.string;

public class Reverse {
    public static void main(String[] args) {
        String st="madam";

        String reverse="";
        for (int i=st.length()-1;i>=0;i--)
        {
            reverse = reverse+st.charAt(i);

        }
        if (st.equals(reverse))
        {
            System.out.println("Polidome");
        }
        else
        {
            System.out.println("Not Pplidrome");
        }

    }
}
