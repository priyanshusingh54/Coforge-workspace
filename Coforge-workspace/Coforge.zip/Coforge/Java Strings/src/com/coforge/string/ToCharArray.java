package com.coforge.string;

public class ToCharArray {
    public static void main(String[] args) {
        String s="Akash Singh";
        char[] c=s.toCharArray();

        System.out.println(c);
        for (char s2:c)
        {
            System.out.println(s2);
        }
    }
}
