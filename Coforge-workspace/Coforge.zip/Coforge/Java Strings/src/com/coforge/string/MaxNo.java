package com.coforge.string;

import java.util.Arrays;

public class MaxNo {
    public static void main(String[] args) {

        int a[]={2,6,4,3,8,1};
        int max=a[3];
        
        for (int i=1;i<a.length;i++)
        {
            if (a[i]>max)
            {
                max=a[i];
            }
        }
        System.out.println(max);
        System.out.println(a[0]);
    }
}
