package com.coforge.string;

public class StringBuffers {
    public static void main(String[] args) {
        StringBuffer s=new StringBuffer("Akash Singh");

        System.out.println(s.deleteCharAt(3));
        System.out.println(s.append(" Hello"));
        System.out.println(s.capacity());
        System.out.println(s.reverse());
        System.out.println(s.substring(2,5));
        System.out.println(s.replace(1,5,"La"));




    }
}
