package com.coforge.string;

public class ValueOf {
    public static void main(String[] args) {
        int a=10;
        String s=String.valueOf(a); // it will convert integer into String
        System.out.println(s);
    }
}
