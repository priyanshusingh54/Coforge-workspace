package com.coforge.string;

public class Join {
    public static void main(String[] args) {
        String s1="Hello my name is Akash";
        String s2="I am from Azamgarh Uttar Pradesh";
        System.out.println(String.join(",",s1,s2));
        // Joins are use for joining two string and separate with , => s1,s2
    }
}
