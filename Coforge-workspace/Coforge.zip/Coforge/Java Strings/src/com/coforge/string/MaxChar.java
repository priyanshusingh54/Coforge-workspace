package com.coforge.string;

import java.util.HashMap;
import java.util.Map;

public class MaxChar {
    public static void main(String[] args) {
        String a="xyyzzz";
        char[] c =a.toCharArray();
        HashMap<Character,Integer>hashMap=new HashMap<>();
        for (char ch:c)
        {
            if (hashMap.containsKey(ch))
            {
                hashMap.put(ch, hashMap.get(ch)+1);
            }
            else
            {
                hashMap.put(ch,2);
            }
        }
        int max=0;
        char b=' ';

        for (Map.Entry<Character,Integer>me: hashMap.entrySet())
        {
            max=me.getValue();
            b=me.getKey();
        }
        System.out.println(b +"= "+ max);
    }
}
