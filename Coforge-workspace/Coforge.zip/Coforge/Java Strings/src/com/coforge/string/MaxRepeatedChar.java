package com.coforge.string;

import java.util.HashMap;
import java.util.Map;

public class MaxRepeatedChar {
    public static void main(String[] args) {
        String s="abbccc";
        HashMap<Character,Integer> hm=new HashMap<>();
        char[] c=s.toCharArray();
        for (char ch:c)
        {
            if (hm.containsKey(ch))
            {
                hm.put(ch,hm.get(ch)+1);
            }
            else
            {
                hm.put(ch,1);
            }
        }
        int max=0;
        char b=' ';

        for (Map.Entry<Character,Integer> me: hm.entrySet())
        {
           if (max< me.getValue())
           {
               max=me.getValue();
               b=me.getKey();

           }

        }
        System.out.println(b+"="+max);


    }
}
