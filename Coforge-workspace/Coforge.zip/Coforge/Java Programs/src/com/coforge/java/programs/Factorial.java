package com.coforge.java.programs;

public class Factorial {
    public static void main(String[] args) {
        int n=5; int fact=1;
        for ( int i=1;i<=n;i++)
        {
           fact=fact*i;   // 1,2,6,24,120

        }
        System.out.println(fact);
    }
}
