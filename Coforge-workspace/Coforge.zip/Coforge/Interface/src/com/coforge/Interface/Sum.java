package com.coforge.Interface;

public class Sum implements Addition{
    public void Sum1(int a, int b){
        System.out.println(a+b);
    }
     public void Sum2(int c, double d)
     {
        System.out.println(c+d);

    }


    public static void main(String[] args) {
        Sum sum = new Sum();
        sum.Sum1(2,3);
        sum.Sum2(4,6.5);

    }
}
