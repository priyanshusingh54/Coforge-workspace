package com.coforge.Interface;

public interface Addition {
    void Sum1(int a, int b);
    void Sum2(int b , double d);
}
