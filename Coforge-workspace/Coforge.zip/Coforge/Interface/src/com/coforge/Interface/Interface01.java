package com.coforge.Interface;

public class Interface01 implements Interface1{
    public void sum()
    {
        System.out.println("It's InterFace 1");
    }
    public void sub(){
        System.out.println("2");
    }
    public static void main(String[] args) {
        Interface01 interface01 = new Interface01();
        interface01.sub();
        interface01.sum();


    }
}
