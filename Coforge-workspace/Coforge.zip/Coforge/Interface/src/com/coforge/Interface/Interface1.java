package com.coforge.Interface;

public interface Interface1 {
    void sum();
    void sub();
}
