package com.coforge.Interface;

public interface Test {
     static  void sum1(){
        System.out.println("");
    }
    static void sum2(){
        System.out.println("");
    }
}
