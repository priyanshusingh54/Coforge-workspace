package com.coforge.Interface;

public class TestSum implements Test {
    static void sum1(int a,int b){
        System.out.println(a+b);
    }
    static void sum2(int c,int d){
        System.out.println(c+d);
    }
    public static void main(String[] args) {
//        TestSum testSum = new TestSum();
//        testSum.sum1(2,5);
//        testSum.sum2(7,3);
//
        sum2(28,2);
    }
}
