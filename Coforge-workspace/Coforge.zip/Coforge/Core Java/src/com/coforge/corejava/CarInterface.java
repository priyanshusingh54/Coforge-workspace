package com.coforge.corejava;

public interface CarInterface {
      void ride();

    void ride2();
}
