package com.coforge.corejava;

public class Throw2 {
    void Sum(int a, int b )
    {
        if (b==0)
        {
            throw new ArithmeticException("good");
        }
        else
        {
            int c=a+b;
            System.out.println(c);
        }
    }
    public static void main(String[] args) {

        Throw2 throw2=new Throw2();
        try {
            throw2.Sum(4,0);
        }
        catch (Exception e)
        {
            System.out.println("you should check your code");
        }


    }
}
