package com.coforge.corejava;

public interface Interface1 {
    void good();
    void best();
}
