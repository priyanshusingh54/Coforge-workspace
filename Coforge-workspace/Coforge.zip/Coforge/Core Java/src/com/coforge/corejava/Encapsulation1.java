package com.coforge.corejava;

public class Encapsulation1 {
    private String name;
    private String id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
