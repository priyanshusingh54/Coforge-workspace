package com.coforge.corejava;

class Test extends  Exception{
    void checkString(String msg)
    {
        System.out.println(msg);
    }

}
public class Throws1{
    static void check(String a, String b) throws Test
    {
        if (!b.contains(a))
        {
            throw new ArithmeticException("Not found");
        }
        else
        {
            System.out.println("Found");
        }
    }

    public static void main(String[] args){
        try {
            check("lo", "hello");
        }
        catch (Exception e)
        {
            System.out.println("Please Check your code");

        }
    }
}
