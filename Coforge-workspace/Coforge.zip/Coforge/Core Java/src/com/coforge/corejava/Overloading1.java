package com.coforge.corejava;

class SuperCar{
    void sum(int a, int b)
    {
        System.out.println(a+b);
    }
    void sub(int a, int b)
    {
        System.out.println(a-b);

    }
}

public class Overloading1 extends SuperCar{
    void sum(int a, int b)
    {

    }
    public static void main(String[] args) {
        Overloading1 overloading1=new Overloading1();
        overloading1.sub(52,47);
        overloading1.sum(34,30);

        System.out.println(overloading1.getClass());
    }
}
