package com.coforge.corejava;

import java.util.Locale;

public class StringMethods {

    public static void main(String[] args) {
        String s3=new String("Gautam");
        String s4=new String("Gautam");

       String s="  Akash";
       String s1="  Akash";
        System.out.println(s.equals(s1));// compare the content

        System.out.println(s3==s4);// == operator will compare object(s3 & s4)

        System.out.println(s.trim().length());// count length

        System.out.println(s.trim());// It will remove  pre- and post-spaces

        System.out.println(s3.concat(s4));// adding two String s3 + s4
        System.out.println(s3+5+s4+10+2);// adding two String s3 + s4

        System.out.println(s3.endsWith("am")); // checking suffix

        System.out.println( String.join(",",s,s3));
       ;

    }
}
