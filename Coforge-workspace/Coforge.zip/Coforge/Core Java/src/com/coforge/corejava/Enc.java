package com.coforge.corejava;

public class Enc extends Abstraction1{
    public static void main(String[] args) {
        Encapsulation1 encapsulation1=new Encapsulation1();
        encapsulation1.setName("Akash");

        System.out.println(encapsulation1.getName());

    }
}
