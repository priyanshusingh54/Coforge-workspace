package com.coforge.corejava;

import java.util.Scanner;

class Display extends Exception{

}
public class Throw3 {

    public static void main(String[] args) throws Display {
        Scanner scanner1=new Scanner(System.in);
        System.out.println("Enter your 1st word");
        String a=scanner1.nextLine();
        Scanner scanner2=new Scanner(System.in);
        System.out.println("Enter your 2nd word");
        String b=scanner2.nextLine();


        try
        {
            if (!b.contains(a))
            {
                throw new ArithmeticException("Not Found");
            }
            else
            {
                System.out.println("Found");
            }
        }
        catch (Exception e) {
            System.out.println("you should check your code ");
        }

    }
}
