package com.coforge.corejava;
public class Throw1 {
    void display(int age){
        if (age<=2)
        {
            throw new ArithmeticException("Not eligible");
        }
        else
        {
            System.out.println("eligible");
        }
    }
    public static void main(String[] args) {
       Throw1 throw1= new Throw1();
       throw1.display(23);

    }
    
}
