package com.coforge.corejava;

public class CarInterface1 implements CarInterface{
    public void ride(){
        System.out.println("123");
    }
    public void ride2(){
        System.out.println("456");
    }

    public static void main(String[] args) {
        CarInterface carInterface= new CarInterface1();
        carInterface.ride();
        carInterface.ride2();

    }
}
