package com.coforge.corejava;

public class Interface01 implements Interface1{
    public void good(){
        System.out.println("Hello 1");
    }
    public void best(){
        System.out.println("Hello 2");
    }
    public static void main(String[] args) {
        Interface1 interface1=new Interface01();
        interface1.best();
        interface1.good();
        Interface01 interface01=new Interface01();
        interface01.best();
        interface01.good();

    }

}
