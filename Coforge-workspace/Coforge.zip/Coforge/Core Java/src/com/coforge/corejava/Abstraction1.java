package com.coforge.corejava;

abstract class Sun{
   abstract void Heat();

}

public class Abstraction1 extends Sun{
    void abs()
    {
        System.out.println("This is abs");
    }
    public static void main(String[] args) {
        Abstraction1 abstraction1=new Abstraction1();
        abstraction1.abs();
        abstraction1.Heat();
        System.out.println(abstraction1.getClass());
    }


    //@Override
    void Heat() {

    }
}
