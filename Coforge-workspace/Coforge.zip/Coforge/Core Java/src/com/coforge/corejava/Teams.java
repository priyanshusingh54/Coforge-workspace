package com.coforge.corejava;

public class Teams {
    public static void main(String[] args) {
        int a[]={2,4,5,6,8};
        System.out.println(a);
        for (int i:a){
            System.out.println(i);
        }
    }
}
