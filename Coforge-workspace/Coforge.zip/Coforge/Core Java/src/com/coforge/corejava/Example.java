package com.coforge.corejava;

public class Example extends Exception {
}
