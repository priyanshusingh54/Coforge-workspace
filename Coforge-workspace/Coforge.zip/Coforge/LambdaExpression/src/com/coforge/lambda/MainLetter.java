package com.coforge.lambda;

public class MainLetter {
    public static void main(String[] args) {
        Letter letter = str -> str.length();
        Letter letter1 = str -> str.length();
        System.out.println(letter.Alpha("hello"));
        System.out.println(letter1.Alpha("Priyanshu"));
    }
}
