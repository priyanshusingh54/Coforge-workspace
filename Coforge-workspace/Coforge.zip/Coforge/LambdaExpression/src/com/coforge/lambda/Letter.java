package com.coforge.lambda;

public interface Letter {
    public abstract int Alpha(String str);
}
