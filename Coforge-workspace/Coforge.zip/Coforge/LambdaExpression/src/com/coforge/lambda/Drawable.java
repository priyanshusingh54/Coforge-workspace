package com.coforge.lambda;

public interface Drawable {
     void Draw();
}
