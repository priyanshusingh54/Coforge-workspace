package com.coforge.lambda;

public class MyInter implements Inter {

    @Override
    public void Hello() {

    }
}
