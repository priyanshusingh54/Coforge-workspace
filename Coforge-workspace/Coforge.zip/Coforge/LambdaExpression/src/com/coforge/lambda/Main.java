package com.coforge.lambda;

public class Main {
    public static void main(String[] args) {
       // MyInter i = new MyInter();

     //   MyInter i = () -> System.out.println("hello");
     //   i.Hello();


    //    System.out.println("Hello ");

        SumInter sumInter =(int a ,int b) -> {
            return a + b;
        };


            System.out.println(sumInter.sum(2,4));
            System.out.println(sumInter.sum(2,3));


    }
}
