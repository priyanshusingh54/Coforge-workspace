package com.coforge.lambda;
@FunctionalInterface
interface Say{

     String say();
}
public class Test{
    public static void main(String[] args) {
        Say s=()->"I have nothing tom say.";

        System.out.println(s.say());
    }
}
