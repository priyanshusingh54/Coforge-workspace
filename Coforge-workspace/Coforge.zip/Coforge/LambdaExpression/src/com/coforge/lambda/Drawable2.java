package com.coforge.lambda;
@FunctionalInterface
public interface Drawable2 {
   public abstract int sayHello();
}
