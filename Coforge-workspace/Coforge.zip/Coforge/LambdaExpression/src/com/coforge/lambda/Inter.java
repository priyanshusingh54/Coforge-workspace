package com.coforge.lambda;

@FunctionalInterface
public interface Inter {

    public abstract void Hello();


}
