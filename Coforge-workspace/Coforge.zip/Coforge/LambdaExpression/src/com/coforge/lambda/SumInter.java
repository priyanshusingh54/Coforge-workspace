package com.coforge.lambda;

@FunctionalInterface
public interface SumInter {
    public abstract int sum(int a, int b );
}
