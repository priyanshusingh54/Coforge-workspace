package com.coforge.company;

public class MultidimensionalArrays {
    public static void main(String[] args) {
        int [][] a = {{1,2,3},{4,5,6}};
        System.out.println(a[1][1]);
    }
}
