package com.coforge.company;

import java.util.Enumeration;
import java.util.Scanner;

public class Polindrome2 {

    public static void main(String[] args) {
        int num,temp=0,num1,rev=0;
        System.out.println("Enter your no : ");
        Scanner sc=new Scanner(System.in);
        num =sc.nextInt();
        num1=num;
        while (num>0)
        {
            temp=num%10;
            rev=(rev*10)+temp;
            num=num/10;
        }
        if (num1==rev)
            System.out.println("polindrome no");
        else
            System.out.println("not Polidrome");
    }
}
