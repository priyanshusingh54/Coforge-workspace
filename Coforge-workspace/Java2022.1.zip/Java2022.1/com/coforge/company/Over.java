package com.coforge.company;

public class Over {
    void Actor(){
        System.out.println("over acting");
    }
    void Actress(){
        System.out.println("Ok Ok...");
    }
}
