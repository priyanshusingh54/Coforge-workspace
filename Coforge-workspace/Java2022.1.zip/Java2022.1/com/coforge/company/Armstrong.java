package com.coforge.company;

import java.util.Scanner;

public class Armstrong {
    public static void main(String[] args) {
        int num,num1,temp=0,rev=0;
        System.out.println("Enter your no:=  ");
        Scanner sc = new Scanner(System.in);
        num=sc.nextInt();
        num1=num;
        while (num>0) {
            temp = num %10;
            rev = rev + temp * temp * temp;
            num = num /10;
        }

            if (rev==num1)
                System.out.println("Armastrng No");
            else
                System.out.println("not Aramstrong No");
        }
    }

