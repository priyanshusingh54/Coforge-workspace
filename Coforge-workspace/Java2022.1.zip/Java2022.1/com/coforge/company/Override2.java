package com.coforge.company;

public class Override2 extends Over {
    public static void main(String[] args) {

        Override2 override2 = new Override2();
        override2.Actor();
        override2.Actress();
    }
}
