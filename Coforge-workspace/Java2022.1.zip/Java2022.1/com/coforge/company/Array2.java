package com.coforge.company;

public class Array2 {
    public static void main(String[] args) {
        int i = 0;
        int[] a = {1, 2, 3, 4, 5};
        for (i = 0; i < a.length; i++) {

                System.out.println(i);

        }
    }
}
