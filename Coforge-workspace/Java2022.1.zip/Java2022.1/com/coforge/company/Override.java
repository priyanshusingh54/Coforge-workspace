package com.coforge.company;

class Superman{
    void Tom(){
        System.out.println("One");
    }
     void Jerry(){
        System.out.println("Two");
    }
}

public class Override extends Superman {
    public static void main(String[] args) {
       Override override = new Override();
        override.Tom();
        override.Jerry();

    }
}
