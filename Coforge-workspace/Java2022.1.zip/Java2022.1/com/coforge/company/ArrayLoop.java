package com.coforge.company;

public class ArrayLoop {
    public static void main(String[] args) {
        int [] a = {2,4,3,2,1};
                for (int i:a )
                    System.out.println(i);

    }
}
