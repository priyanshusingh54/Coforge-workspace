package com.coforge.company;

class SuperCar{
    void Run(){
        System.out.println("New");
    }
}
public class Overriding extends SuperCar {
    public static void main(String[] args) {
        Overriding overriding = new Overriding();
        overriding.Run();

    }
}
