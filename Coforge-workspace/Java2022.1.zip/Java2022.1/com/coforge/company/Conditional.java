package com.coforge.company;

import java.util.Scanner;

public class Conditional {
    public static void main(String[] args) {
        System.out.println("Enter your 1st no : ");
        Scanner sc = new Scanner(System.in);
        int a=sc.nextInt();
        System.out.println("Enter your 2nd no : " );
        int b=sc.nextInt();
        System.out.println("Enter your 3nd no : ");
        int c=sc.nextInt();
        sc.close();
        int x = a+b+c;
        System.out.println("The totall sum of given no is :  " +x);

    }
}
