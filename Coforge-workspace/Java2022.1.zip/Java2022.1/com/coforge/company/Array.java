package com.coforge.company;

public class Array {
    public static void main(String[] args) {
        int [] a = {1,2,3,4,5};
        a[4]=20;
        System.out.println(a[4]);
    }
}
