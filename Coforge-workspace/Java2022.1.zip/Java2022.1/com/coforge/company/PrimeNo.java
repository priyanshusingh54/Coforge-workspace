package com.coforge.company;

import java.util.Scanner;

public class PrimeNo {
    public static void main(String[] args) {
        int num,i,count=0;
        System.out.println("Enter your no:=  ");
        Scanner sc = new Scanner(System.in);
        num=sc.nextInt();
        for (i=2;i<num;i++) {
            if (num % i == 0) {
                count++;
                break;
            }
        if (count==0) {
                System.out.println("prime no");
            }
        else
                System.out.println("not prime no");
        }
    }
}
