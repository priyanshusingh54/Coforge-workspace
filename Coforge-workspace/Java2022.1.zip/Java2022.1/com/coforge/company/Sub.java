package com.coforge.company;

import java.sql.SQLOutput;

public class Sub {
    public static void main(String[] args) {
        int a=1,b=4;
        System.out.println(a+b);
    }
}
