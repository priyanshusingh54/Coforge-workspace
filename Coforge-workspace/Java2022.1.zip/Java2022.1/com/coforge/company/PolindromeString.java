package com.coforge.company;

import java.util.Scanner;

public class PolindromeString{
    public static void main(String[] args) {
        String str,rev=" ";
        System.out.println("Enter your string");
        Scanner sc=new Scanner(System.in);
        str=sc.nextLine();
        int len = str.length();
        for (int i=len-1;i>=0;i--)
            rev=rev+str.charAt(i);
        if (str.equals(rev))
            System.out.println(str+"Polidrome no");
        else
            System.out.println(str+"not polidrome");
    }

}
