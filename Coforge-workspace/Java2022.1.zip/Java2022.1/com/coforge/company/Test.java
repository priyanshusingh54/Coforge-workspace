package com.coforge.company;

public class Test {
    static void Sum(int a, int b) {
        System.out.println(a+b);
    }
    void Sub(int c, int d){
        System.out.println(c-d);
    }


    public static void main(String args[]){
        Test test= new Test();

        Sum(2,3);
        test.Sub(4,3);


        }
    }

