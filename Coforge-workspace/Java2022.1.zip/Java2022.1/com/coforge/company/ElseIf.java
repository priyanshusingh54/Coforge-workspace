package com.coforge.company;

import java.util.Scanner;

public class ElseIf {
    public static void main(String[] args) {
        System.out.println("Enter your  no : ");
        Scanner sc = new Scanner(System.in);
        int age = sc.nextInt();
        if (age>18)
        {
            System.out.println("you are  allowed");

        } else if (age>15) {
            System.out.println("may be you can go but not sure");

        }
        else
            System.out.println("you are not allowed");
        switch (age)
        {
            case 10:
                System.out.println("you can't go ");
            case 20:
                System.out.println("you can  go man");
                break;
            case 23:
                System.out.println("you are allowed");
            default:
                System.out.println("well ");
        }
    }
}
