package com.coforge.company;

public class TryCatch {
    public static void main(String[] args) {
        String[] cars = {"BMW", "Maruti", "Honda", "KIA"};
        try {
            System.out.println(cars[4]);  // when cars>3 then try and will excute
        } catch (Exception e) {
//            System.out.println("You are entering worng car ");

        }
        finally {
            System.out.println("well done");
        }
    }
}