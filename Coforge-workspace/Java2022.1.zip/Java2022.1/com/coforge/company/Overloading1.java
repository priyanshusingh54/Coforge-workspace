package com.coforge.company;

class Car {
    static int run(int a,int b){

        return a+b;
    }
    static double run(double a,double b){
        return a+b;
    }

    };



public class Overloading1 {
    public static void main(String[] args) {


        System.out.println(Car.run(2,4));
        System.out.println(Car.run(5.5,4.5));
    }
}
