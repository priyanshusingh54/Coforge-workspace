package com.coforge.company;

import java.util.Scanner;

public class EvenOdd {
    public static void main(String[] args) {
        System.out.println("Enter your no : ");
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        if (num%2==0)
        {
            System.out.println("even");
        }
        else
            System.out.println("odd");
    }
}
