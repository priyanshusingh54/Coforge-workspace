package com.coforge.streamAPI;

import java.util.stream.Stream;

public class StreamTable {
    public static void main(String[] args) {
        Stream<Integer> stream = Stream.empty();
        stream.forEach(a->{
            System.out.println(a);
        });
    }
}
